package edu.elon.quiz4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.elon.quiz4.entity.Applicant;
import edu.elon.quiz4.service.ApplicantService;

@Controller
@RequestMapping("/applicant")
public class ApplicantController {
	
	@Autowired
	private ApplicantService applicantService;
	
	@GetMapping("/list")
	public String listApplicants(Model theModel) {
		List<Applicant> theApplicants = applicantService.getApplicants();
		
		theModel.addAttribute("applicants", theApplicants);
		
		return "list-applicants";
		
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Applicant theApplicant = new Applicant();
		
		theModel.addAttribute("applicant", theApplicant);
		
		return "applicant-form";
	}
	
	@PostMapping("/saveApplicant")
	public String saveApplicant(@ModelAttribute("applicant") Applicant theApplicant) {
		applicantService.saveApplicant(theApplicant);
		
		return "redirect:/applicant/list";
	}

}
