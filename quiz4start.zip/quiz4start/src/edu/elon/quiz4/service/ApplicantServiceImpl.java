package edu.elon.quiz4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.elon.quiz4.dao.ApplicantDAO;
import edu.elon.quiz4.entity.Applicant;

@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	private ApplicantDAO applicantDAO;
	
	@Override
	@Transactional
	public List<Applicant> getApplicants() {
		return applicantDAO.getApplicants();
	}

	@Override
	@Transactional
	public void saveApplicant(Applicant theApplicant) {
		applicantDAO.saveApplicant(theApplicant);

	}

}
