package edu.elon.quiz4.service;

import java.util.List;

import edu.elon.quiz4.entity.Applicant;

public interface ApplicantService {

	public List<Applicant> getApplicants();
	
	public void saveApplicant(Applicant theApplicant);
	

}
