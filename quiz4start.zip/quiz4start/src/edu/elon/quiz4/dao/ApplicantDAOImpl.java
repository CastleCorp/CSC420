package edu.elon.quiz4.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.elon.quiz4.entity.Applicant;

@Repository
public class ApplicantDAOImpl implements ApplicantDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Applicant> getApplicants() {
		Session currentSession = sessionFactory.getCurrentSession();
		
		Query<Applicant> theQuery = currentSession.createQuery(
				"from Applicant order by position, id",
				Applicant.class);
		
		List<Applicant> applicants = theQuery.getResultList();
		
		return applicants;
	}

	@Override
	public void saveApplicant(Applicant theApplicant) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		currentSession.save(theApplicant);

	}

}
