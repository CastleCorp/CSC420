DROP DATABASE IF EXISTS quiz4;

CREATE DATABASE quiz4;

USE quiz4;

DROP TABLE IF EXISTS Applicant;

CREATE TABLE applicant (
   id int NOT NULL AUTO_INCREMENT,
   name varchar(50) NOT NULL,
   position varchar(50) NOT NULL,
   salary decimal(10,2) NOT NULL,
   location varchar(50) NOT NULL,
   PRIMARY KEY (id)
   );
   
INSERT INTO applicant (name, position, salary, location)
 VALUES ('Edward Elon', 'Tester', 65000.00, 'Massachusetts'),
		('Elon Musk', 'Product Manager', 100000.00, 'North Carolina');
 
   
    