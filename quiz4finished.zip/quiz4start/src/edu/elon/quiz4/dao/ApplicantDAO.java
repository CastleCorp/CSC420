package edu.elon.quiz4.dao;

import java.util.List;

import edu.elon.quiz4.entity.Applicant;

public interface ApplicantDAO {

	public List<Applicant> getApplicants();

	public void saveApplicant(Applicant theApplicant);

}
