package edu.elon.quiz4.entity;

import java.util.LinkedHashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="applicant")
public class Applicant {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@NotNull(message="this field is required")
	@Size(min=5, message="is required to be at least 5 characters")
	@Column(name="name")
	private String name;
	
	@Column(name="position")
	private String position;
	
	@Transient
	private LinkedHashMap<String, String> positionOptions;
	
	@Min(value=20000, message="must be greater than or equal to 20,000")
	@Max(value=200000, message="must be less than or equal to 200,000")
	@Column(name="salary")
	private double salary;
	
	@Column(name="location")
	private String location;
	
	@Transient
	private LinkedHashMap<String, String> locationOptions;
	
	public Applicant() {
		locationOptions = new LinkedHashMap<>();
		positionOptions = new LinkedHashMap<>();
		
		positionOptions.put("Product Manager", "Product Manager");
		positionOptions.put("Architect", "Architect");
		positionOptions.put("Senior Developer", "Senior Developer");
		positionOptions.put("Junior Developer", "Junior Developer");
		positionOptions.put("Software Documentation", "Software Documentation");
		positionOptions.put("Tester", "Tester");
		positionOptions.put("Marketing", "Marketing");
		
		locationOptions.put("Massachusetts", "Massachusetts");
		locationOptions.put("New Jersey", "New Jersey");
		locationOptions.put("New Hampshire", "New Hampshire");
		locationOptions.put("North Carolina", "North Carolina");		
		locationOptions.put("Texas", "Texas");
		locationOptions.put("Rhode Island", "Rhode Island");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public LinkedHashMap<String, String> getPositionOptions() {
		return positionOptions;
	}

	public void setPositionOptions(LinkedHashMap<String, String> positionOptions) {
		this.positionOptions = positionOptions;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LinkedHashMap<String, String> getLocationOptions() {
		return locationOptions;
	}

	public void setLocationOptions(LinkedHashMap<String, String> locationOptions) {
		this.locationOptions = locationOptions;
	}

	@Override
	public String toString() {
		return "Applicant [id=" + id + ", name=" + name + ", position=" + position + ", positionOptions="
				+ positionOptions + ", salary=" + salary + ", location=" + location + ", locationOptions="
				+ locationOptions + "]";
	}
	

}
