package edu.elon.quiz5.entity;

import java.text.NumberFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="applicant")
public class Applicant {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	@NotNull(message="is required")
	@Size(min=5, message="is required to be at least 5 characters")
	private String name;
	
	@Column(name="position")
	private String position;
	
	@Min(value=20000, message="must be greater than or equal to 20,000")
	@Max(value=200000, message="must be less than or equal to 200,000")
	@Column(name="salary")
	private double salary;
	
	@Column(name="location")
	private String location;
	
	public Applicant() {
		// intentionally empty
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public double getSalary() {
		return salary;
	}
	
	public String getFormattedSalary() {
		NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
		System.out.println("Formatted number is: " + defaultFormat.format(salary));
	    return defaultFormat.format(salary);
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Applicant [id=" + id + ", name=" + name + ", position=" + position + ", salary=" + salary
				+ ", location=" + location + "]";
	}
}
