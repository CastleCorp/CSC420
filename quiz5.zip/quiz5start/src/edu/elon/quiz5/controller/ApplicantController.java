package edu.elon.quiz5.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import edu.elon.quiz5.entity.Applicant;
import edu.elon.quiz5.service.ApplicantService;

@Controller
@RequestMapping("/applicant")
public class ApplicantController {
	
	// need to inject our customer service
	@Autowired
	private ApplicantService applicantService; 
	
	@GetMapping("/list")
	public String listApplicants(Model theModel) {
		
		System.out.println("Entering Controller");
		
		// get the customers from the service
		List<Applicant> theApplicants = applicantService.getApplicants();
		
		// add the customers to the model
		theModel.addAttribute("applicants", theApplicants);
		
		return "list-applicants";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		System.out.println("In Controller showFormForAdd");
		
		// create model attribute to bind form data
		Applicant theApplicant = new Applicant();
		
		theModel.addAttribute("applicant", theApplicant);
		
		return "applicant-form";
	}
	
	@PostMapping("/saveApplicant")
	public String saveApplicant(
			@Valid @ModelAttribute("applicant") Applicant theApplicant, 
			BindingResult theBindingResult,
			Model theModel) {
		
		System.out.println("In Controller saveApplicant");
		System.out.println("Binding result: " + theBindingResult);
		
		if (theBindingResult.hasErrors()) {
			return "applicant-form";
		}
		
		// theModel.addAttribute("applicant", theApplicant);
		applicantService.saveApplicant(theApplicant);
		
		return "redirect:/applicant/list";
	}
	
}
