package edu.elon.quiz5.dao;

import java.util.List;

import edu.elon.quiz5.entity.Applicant;

public interface ApplicantDAO {
	
	public List<Applicant> getApplicants();
	
	public void saveApplicant(Applicant theApplicant);

	public Applicant getApplicant(int theId);

}
