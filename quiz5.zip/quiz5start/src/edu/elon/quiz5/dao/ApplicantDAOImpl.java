package edu.elon.quiz5.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.elon.quiz5.entity.Applicant;

@Repository
public class ApplicantDAOImpl implements ApplicantDAO {
	
	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Applicant> getApplicants() {
		 
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		System.out.println("Entering DAO");
		
		// create a query ... sort by last name
		Query<Applicant> theQuery = 
				currentSession.createQuery("from Applicant order by position, id", 
						Applicant.class);
		
		// execute query and get result list
		List<Applicant> applicants = theQuery.getResultList();
		
		System.out.println("Leaving DAO " + applicants);
		
		// return the results
		return applicants;
	}

	 

	@Override
	public Applicant getApplicant(int theId) {
		
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// now retrieve/read from database using the primary key
		Applicant theApplicant = currentSession.get(Applicant.class, theId);
		
		return theApplicant;
	}
	
	@Override
	public void saveApplicant(Applicant theApplicant) {
		
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// save the customer to the database
		currentSession.saveOrUpdate(theApplicant);
		
	}

	 

}
