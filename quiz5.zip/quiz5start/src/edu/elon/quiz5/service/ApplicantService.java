package edu.elon.quiz5.service;

import java.util.List;

import edu.elon.quiz5.entity.Applicant;

public interface ApplicantService {

	public List<Applicant> getApplicants();

	public Applicant getApplicant(int theId);
	
	public void saveApplicant(Applicant theApplicant);

}
