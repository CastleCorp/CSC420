package edu.elon.quiz5.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.elon.quiz5.dao.ApplicantDAO;
import edu.elon.quiz5.entity.Applicant;

@Service
public class ApplicantServiceImpl implements ApplicantService {

	// need to inject customer dao
	@Autowired
	private ApplicantDAO applicantDAO;
	
	@Override
	@Transactional
	public List<Applicant> getApplicants() {
		
		System.out.println("Entering service get applicants");
		
		return applicantDAO.getApplicants();
	}


	@Override
	@Transactional
	public Applicant getApplicant(int theId) {
		 
		return applicantDAO.getApplicant(theId);
	}
	
	@Override 
	@Transactional
	public void saveApplicant(Applicant theApplicant) {
		
		System.out.println("Entering service saveApplicant");
		
		applicantDAO.saveApplicant(theApplicant);
	}

}
