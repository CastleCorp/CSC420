package edu.elon.quiz5.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import edu.elon.quiz5.entity.Applicant;

import java.util.Iterator;
import java.util.List;

import org.aspectj.lang.annotation.AfterReturning;

@Aspect
@Component
public class FilteringAspect {

	@AfterReturning(
			pointcut="execution (* edu.elon.quiz5.dao.ApplicantDAOImpl.getApplicants(..))",
			returning="result")
	public void afterReturningGetApplicantsAdvice(List<Applicant> result) {
		
		System.out.println("\n===>>> Returned " + result.size() + " applicants...");
		

		System.out.println("\n===>>> Filtering out applicants");
		
		Applicant tempApplicant = new Applicant();
		tempApplicant.setName("Edward Elon");
		tempApplicant.setLocation("Massachusetts");
		
		Iterator<Applicant> resultIterator = result.iterator();
		
		while(resultIterator.hasNext()) {
			if(resultIterator.next().getName().equalsIgnoreCase("edward elon") && resultIterator.next().getLocation().equalsIgnoreCase("massachusetts")) {
				resultIterator.remove();
			}
		}
		
		
		System.out.println("\n===>>> Filtering complete, returning " + result.size() + " applicant");
		
		}
	
	
}
