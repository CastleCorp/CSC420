package edu.elon.quiz.mvc;

import java.util.LinkedHashMap;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class Employee {
	
	@NotNull(message="is required to be at least 5 characters")
	@Size(min=5, message="is required to be at least 5 characters")
	private String name;
	
	@NotNull(message="is required")
	@Min(value=20000, message="must be greater than or equal to 20,000")
	@Max(value=1000000, message="must be less than or equal to 1,000,000")
	private Double salary;
	
	@NotNull(message="is required to be at least 5 characters")
	@Size(min=5, message="is required to be at least 5 characters")
	private String designation;
	
	private String location;

	private LinkedHashMap<String, String> locationOptions;
	
	public Employee() {
		locationOptions = new LinkedHashMap<>();
		
		locationOptions.put("Massachusetts", "Massachusetts");
		locationOptions.put("New Jersey", "New Jersey");
		locationOptions.put("New Hampshire", "New Hampshire");
		locationOptions.put("North Carolina", "North Carolina");		
		locationOptions.put("Texas", "Texas");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public LinkedHashMap<String, String> getLocationOptions() {
		return locationOptions;
	}

	public void setLocationOptions(LinkedHashMap<String, String> locationOptions) {
		this.locationOptions = locationOptions;
	}
	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
